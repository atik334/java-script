//var a=(document.getElementById("num1").value);
var f=(document.getElementById("num6").value);
var msg="";

function myfunc(){

if(f=="")
{
msg+="please fill this Degree\n";

}

if(msg==""){

return true;
}
else{

//document.getElementById("result").innerHTML="please fill this Username\n";
document.getElementById("result5").innerHTML="please fill this field\n";
return false;
}
}
function validation(){
//var a=(document.getElementById("num1").value);
var f=(document.getElementById("num6").value);

if(f!="")
{
document.getElementById("result5").innerHTML="";
}
}